(function () {
  'use strict';
  if (window.DaisyCartExtraGifts) return;
  window.DaisyCartExtraGifts = true;
  document.addEventListener('submit', async function(event) {
    var form = event.target.closest('[data-dm-extra-gift]');
    if (!form) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (!form.reportValidity() || form.dataset.busy === 'true') return;
    var button = form.querySelector('button[type="submit"]');
    var error = form.querySelector('[data-gift-error]');
    error.hidden = true;
    form.dataset.busy = 'true';
    button.disabled = true;
    try {
      var properties = {'_Linked product':form.dataset.title,'_Bundle ID':form.dataset.bundle,'_Custom option flow':'Daisy basket second gift'};
      form.querySelectorAll('[data-gift-property]').forEach(function(input) {
        var key = (form.dataset.kind === 'picture' ? '(Offer) ' : '') + input.dataset.giftProperty;
        properties[key] = input.value.trim();
      });
      var select = form.querySelector('select[name="id"]');
      var line = {id:Number(select.value),quantity:1,properties:properties};
      if (form.dataset.kind === 'sign') {
        properties.Offer = 'Second sign';
        properties.Size = select.selectedOptions[0].dataset.title;
        line.parent_line_key = form.dataset.parent;
      }
      if (!window.DaisyCartSubmit) throw new Error(form.dataset.failure);
      var submitter = window.DaisyCartSubmit.create({root:form.dataset.root});
      await submitter.add([line]);
      window.location.assign(form.dataset.root + 'cart');
    } catch (failure) {
      error.textContent = form.dataset.failure;
      error.hidden = false;
      button.disabled = !!failure.reviewCart;
      form.dataset.busy = failure.reviewCart ? 'true' : 'false';
    }
  },true);
})();
