(function () {
  "use strict";

  var SP = window.DAISY_SS_PRICES || { medium: 599, large: 899, mounting: 225, mountingPair: 399, second: 995, giftWrap: 495 };
  var PRODUCT_HANDLE = "family-personalised-street-sign";

  var ASSET_BASE = (function () {
    var node = document.querySelector('script[src*="daisy-family-street-sign"]');
    var url = node && node.src ? node.src.split('?')[0] : '';
    return url ? url.replace(/[^\/]+$/, '') : '';
  })();
  function addonThumb(src, zoom, alt) {
    if (!src) return '';
    return '<img class="dm-cyg__thumb dm-choice-thumb" src="' + src + '" alt="' + alt + '" width="56" height="56" loading="lazy" data-dm-zoomable data-dm-zoom-src="' + (zoom || src) + '">';
  }
  var THUMBS = {
    mounting: ['https://cdn.shopify.com/s/files/1/0897/0017/2115/files/Mounting_strips.jpg?v=1743594751&width=160', 'https://cdn.shopify.com/s/files/1/0897/0017/2115/files/Mounting_strips.jpg?v=1743594751&width=1200', 'Mounting strips'],
    giftwrap: ['https://cdn.shopify.com/s/files/1/0897/0017/2115/files/Screenshot_2026-05-20_164534.jpg?v=1779291954&width=160', 'https://cdn.shopify.com/s/files/1/0897/0017/2115/files/Screenshot_2026-05-20_164534.jpg?v=1779291954&width=1200', 'Gift wrap kit'],
    easel: [ASSET_BASE ? ASSET_BASE + 'dm-easel-street-signs-160.jpg' : '', ASSET_BASE ? ASSET_BASE + 'dm-easel-street-signs.jpg' : '', 'Display easel with personalised signs']
  };

  var LINKED_PRODUCT = "Family Personalised Street Sign Gift";
  var MAIN_VARIANT_ID = 49311753273683;
  var ADDONS = {
    mediumSign:     (window.DAISY_SS_IDS && DAISY_SS_IDS.mediumSign) || 54100431962451,
    largeSign:      (window.DAISY_SS_IDS && DAISY_SS_IDS.largeSign) || 54100431995219,
    mountingStrips: (window.DAISY_SS_IDS && DAISY_SS_IDS.mountingStrips) || 50706678514003,
    mountingPair:   (window.DAISY_SS_IDS && DAISY_SS_IDS.mountingPair) || 54066025759059,
    giftWrapKit:    (window.DAISY_SS_IDS && DAISY_SS_IDS.giftWrap) || 53802540171603,
    secondSign:     52473837355347
  };
  var BORDER_COLOURS = [
    { value: "grass", title: "Grass", colour: "#5f7f42" },
    { value: "sage",  title: "Sage",  colour: "#b0af9b" },
    { value: "blue",  title: "Blue",  colour: "#416f9f" },
    { value: "gray",  title: "Grey",  colour: "#8a8a84" },
    { value: "black", title: "Black", colour: "#111111" }
  ];
  var CART_TIMEOUT_MS = 12000;
  var submitting = false;
  var PREVIEW = window.DAISY_PREVIEW || null;
  var PREVIEW_FONT = "DaisyStreetSignTimes";
  var measureCanvas = document.createElement("canvas");
  var measureContext = measureCanvas.getContext("2d");

  function isTargetProduct() {
    return window.location.pathname.indexOf("/products/" + PRODUCT_HANDLE) !== -1;
  }
  function qs(root, sel) { return (root || document).querySelector(sel); }
  function qsa(root, sel) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function clean(v) { return (v || "").replace(/\s+/g, " ").trim(); }
  function money(v) { return "\xA3" + Number(v).toFixed(2); }
  function escapeHtml(v) {
    return String(v || "").replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function previewNumber(value) { return Math.round(value * 1000) / 1000; }
  function naturalWidth(text) {
    if (!text || !measureContext) return 0;
    measureContext.font = '400 100px "' + PREVIEW_FONT + '", "Times New Roman", serif';
    return measureContext.measureText(text).width / 100;
  }

  function accuratePreviewSvg(label) {
    var p = PREVIEW;
    if (!p) {
      return '<svg class="dm-sign-preview__sign" viewBox="0 0 570 125" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + label + '"><rect class="dm-sign-preview__plate" width="570" height="125"></rect><rect class="dm-sign-preview__inset" x="12.4" y="12.4" width="545.2" height="100.2"></rect><text data-dm-preview-line-one x="285" y="57" text-anchor="middle" fill="#111111" opacity=".42">TYPE HERE</text><text data-dm-preview-line-two x="285" y="93" text-anchor="middle" fill="#111111" opacity=".42">TYPE SMALLER TEXT</text></svg>';
    }
    var holes = (p.holes || []).map(function (hole) {
      return '<circle cx="' + hole.x + '" cy="' + hole.y + '" r="' + hole.r + '" fill="' + p.PANEL + '" stroke="var(--dm-preview-colour, #111111)" stroke-width="0.4"></circle>';
    }).join("");
    return [
      '<svg class="dm-sign-preview__sign" viewBox="0 0 ' + p.viewW + " " + p.viewH + '" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="' + label + '">',
      '<path class="dm-sign-preview__plate" d="' + p.outer + '"></path>',
      '<path class="dm-sign-preview__inset" d="' + p.inner + '"></path>',
      holes,
      '<g data-dm-accurate-line-one opacity=".42"><text x="0" y="0" xml:space="preserve" font-family="' + PREVIEW_FONT + ', Times New Roman, serif" font-weight="400" font-size="' + p.MAX_FS + '" letter-spacing="0" text-anchor="middle" fill="#111111" style="font-synthesis:none">TYPE HERE</text></g>',
      '<g data-dm-accurate-line-two opacity=".42"><text x="0" y="0" xml:space="preserve" font-family="' + PREVIEW_FONT + ', Times New Roman, serif" font-weight="400" letter-spacing="0" text-anchor="middle" fill="#111111" style="font-synthesis:none">TYPE SMALLER TEXT</text></g>',
      '<rect class="dm-sign-preview__caret" data-dm-preview-caret x="0" y="0" width="2.6" height="0" rx="1" fill="#111111" aria-hidden="true"></rect>',
      "</svg>"
    ].join("");
  }

  function directEditorFields(lineOneAttr, lineTwoAttr, secondSign) {
    return [
      '<div class="dm-direct-sign-editor__fields">',
      '<label class="dm-direct-sign-editor__field dm-direct-sign-editor__field--one">',
      '<span class="dm-direct-sign-editor__sr-only">' + (secondSign ? 'Second sign main text' : 'Main sign text') + '</span>',
      '<input type="text" ' + lineOneAttr + ' data-dm-direct-line="one" maxlength="75" autocomplete="off" spellcheck="false" aria-label="' + (secondSign ? 'Second sign main text' : 'Main sign text') + '" placeholder="TYPE HERE">',
      '</label>',
      '<label class="dm-direct-sign-editor__field dm-direct-sign-editor__field--two">',
      '<span class="dm-direct-sign-editor__sr-only">' + (secondSign ? 'Second sign smaller text' : 'Smaller sign text') + '</span>',
      '<input type="text" ' + lineTwoAttr + ' data-dm-direct-line="two" maxlength="75" autocomplete="off" spellcheck="false" aria-label="' + (secondSign ? 'Second sign smaller text' : 'Smaller sign text') + '" placeholder="TYPE SMALLER TEXT">',
      '</label>',
      '</div>'
    ].join('');
  }

  function signPreviewHTML() {
    return [
      '<div class="dm-sign-preview dm-direct-sign-editor" data-dm-sign-preview data-dm-direct-sign-editor>',
      accuratePreviewSvg("Sign preview"),
      directEditorFields('data-daisy-create-line-one', 'data-daisy-create-line-two', false),
      '</div>'
    ].join('');
  }

  function offerSignPreviewHTML() {
    return [
      '<div class="dm-sign-preview dm-direct-sign-editor dm-direct-sign-editor--offer" data-dm-sign-preview-offer data-dm-direct-sign-editor>',
      accuratePreviewSvg("Second sign preview"),
      directEditorFields('data-daisy-family-offer-line-one', 'data-daisy-family-offer-line-two', true),
      '</div>'
    ].join('');
  }

  function setTextGroup(group, x, y, scaleX, scaleY, text) {
    if (!group) return;
    group.setAttribute("transform", "translate(" + previewNumber(x) + " " + previewNumber(y) + ") scale(" + previewNumber(scaleX) + " " + previewNumber(scaleY) + ")");
    var node = qs(group, "text");
    if (node) node.textContent = text || "";
  }

  function renderAccuratePreview(svg, lineOne, lineTwo) {
    var p = PREVIEW;
    if (!p || !svg) return;
    var firstLine = lineOne ? lineOne.toUpperCase() : "TYPE HERE";
    var secondLine = lineTwo ? lineTwo.toUpperCase() : "TYPE SMALLER TEXT";
    var firstNatural = naturalWidth(firstLine) * p.MAX_FS;
    var firstScaleX = firstNatural ? Math.min(1, p.TARGET_W / firstNatural) : 1;
    var firstCapHeight = p.CAP_H * p.MAX_FS * p.VSCALE;
    var firstBaseline = p.CAP_CENTER_Y + firstCapHeight / 2;
    var firstGroup = qs(svg, "[data-dm-accurate-line-one]");
    setTextGroup(firstGroup, p.CX, firstBaseline, firstScaleX, p.VSCALE, firstLine);
    if (firstGroup) firstGroup.setAttribute("opacity", lineOne ? "1" : ".42");

    var secondNatural = naturalWidth(secondLine);
    var secondSize = secondNatural ? Math.min(p.DATE_MAX_FS, p.DATE_TARGET_W / secondNatural) : p.DATE_MAX_FS;
    var secondGroup = qs(svg, "[data-dm-accurate-line-two]");
    setTextGroup(secondGroup, p.CX, p.DATE_BASELINE, 1, p.VSCALE, secondLine);
    var secondNode = qs(secondGroup, "text");
    if (secondNode) secondNode.setAttribute("font-size", previewNumber(secondSize));
    if (secondGroup) secondGroup.setAttribute("opacity", lineTwo ? "1" : ".42");
  }

  function updatePreviewCaret(panel) {
    qsa(panel, "[data-dm-preview-caret]").forEach(function (caret) {
      caret.style.display = "none";
    });
    var input = document.activeElement;
    if (!input || !panel.contains(input) || !input.hasAttribute("data-dm-direct-line") || !PREVIEW) return;
    var editor = input.closest("[data-dm-direct-sign-editor]");
    var svg = editor && qs(editor, "svg");
    var caret = svg && qs(svg, "[data-dm-preview-caret]");
    var line = input.getAttribute("data-dm-direct-line");
    var group = svg && qs(svg, line === "one" ? "[data-dm-accurate-line-one]" : "[data-dm-accurate-line-two]");
    var textNode = group && qs(group, "text");
    var transform = group && group.transform && group.transform.baseVal.consolidate();
    if (!caret || !textNode || !transform) return;
    var raw = input.value || "";
    var selection = typeof input.selectionStart === "number" ? input.selectionStart : raw.length;
    var rendered = clean(raw).toUpperCase();
    var prefix = clean(raw.slice(0, selection)).toUpperCase();
    var totalWidth = rendered && textNode.getComputedTextLength ? textNode.getComputedTextLength() : 0;
    var prefixLength = Math.min(prefix.length, (textNode.textContent || "").length);
    var prefixWidth = rendered && prefixLength && textNode.getSubStringLength
      ? textNode.getSubStringLength(0, prefixLength)
      : 0;
    var fontSize = parseFloat(textNode.getAttribute("font-size")) || (line === "one" ? PREVIEW.MAX_FS : PREVIEW.DATE_MAX_FS);
    var trailingSpaces = rendered && raw.slice(0, selection).match(/ +$/);
    var trailingWidth = trailingSpaces ? naturalWidth(trailingSpaces[0]) * fontSize : 0;
    var localX = rendered ? (-(totalWidth + trailingWidth) / 2) + prefixWidth + trailingWidth : 0;
    var matrix = transform.matrix;
    var rootX = matrix.a * localX + matrix.e;
    var height = Math.max(8, Math.abs(matrix.d) * fontSize * PREVIEW.CAP_H);
    caret.setAttribute("x", previewNumber(rootX - 1.3));
    caret.setAttribute("y", previewNumber(matrix.f - height));
    caret.setAttribute("height", previewNumber(height));
    caret.style.display = "block";
  }

  function updateSignSvg(container, lineOne, lineTwo, colourHex) {
    if (!container) return;
    var svg = container.querySelector("svg");
    if (svg) {
      svg.style.setProperty("--dm-preview-colour", colourHex);
      qsa(svg, "text,[data-dm-preview-caret]").forEach(function (node) { node.setAttribute("fill", colourHex); });
    }
    renderAccuratePreview(svg, lineOne, lineTwo);
  }

  function fitDirectInput(editor, input, line) {
    if (!editor || !input || !PREVIEW) return;
    var width = editor.clientWidth || 0;
    if (!width) return;
    var text = clean(input.value || input.placeholder).toUpperCase();
    var baseSize = width * (line === "one" ? PREVIEW.MAX_FS : PREVIEW.DATE_MAX_FS) * PREVIEW.VSCALE / PREVIEW.viewW;
    var maxWidth = width * (line === "one" ? 0.82 : 0.78);
    var measured = naturalWidth(text);
    var fittedSize = measured ? Math.min(baseSize, maxWidth / measured) : baseSize;
    input.style.fontSize = previewNumber(Math.max(line === "one" ? 10 : 7, fittedSize)) + "px";
  }

  function updateDirectEditors(panel) {
    qsa(panel, "[data-dm-direct-sign-editor]").forEach(function (editor) {
      fitDirectInput(editor, qs(editor, '[data-dm-direct-line="one"]'), "one");
      fitDirectInput(editor, qs(editor, '[data-dm-direct-line="two"]'), "two");
    });
  }

  function updatePreviews(panel) {
    var cur = state(panel);
    var c1 = BORDER_COLOURS.filter(function (c) { return c.value === cur.border; })[0] || BORDER_COLOURS[4];
    var c2 = BORDER_COLOURS.filter(function (c) { return c.value === cur.offerBorder; })[0] || BORDER_COLOURS[4];
    updateSignSvg(qs(panel, "[data-dm-sign-preview]"), cur.lineOne, cur.lineTwo, c1.colour);
    updateSignSvg(qs(panel, "[data-dm-sign-preview-offer]"), cur.offerLineOne, cur.offerLineTwo, c2.colour);
    updateDirectEditors(panel);
    updatePreviewCaret(panel);
  }

  function getForm() {
    var pv = qs(document, '.halo-productView[data-product-handle="' + PRODUCT_HANDLE + '"]');
    var forms = qsa(pv || document, 'product-form form[data-type="add-to-cart-form"],form[action*="/cart/add"]');
    var f = forms.filter(function (form) {
      return !!(form && qs(form, '#product-add-to-cart,button[name="add"]') && qs(form, 'input[name="id"]'));
    })[0];
    return f || forms[0] || null;
  }

  function getProductColumn(form) {
    return form && (form.closest(".halo-productView-right") || form.closest(".productView-details") || form.closest(".productView-info") || form.parentElement);
  }

  function createChoice(type, name, value, checked, title, note, price, extraClass) {
    return [
      '<label class="daisy-street-options__choice ' + (extraClass || "") + '">',
      '<input type="' + type + '" name="' + escapeHtml(name) + '" value="' + escapeHtml(value) + '"' + (checked ? " checked" : "") + ">",
      '<span class="daisy-street-options__choice-main">',
      '<span class="daisy-street-options__choice-title">' + escapeHtml(title) + "</span>",
      note ? '<span class="daisy-street-options__choice-note">' + escapeHtml(note) + "</span>" : "",
      "</span>",
      price ? '<span class="daisy-street-options__price">' + escapeHtml(price) + "</span>" : "",
      "</label>"
    ].join("");
  }

  function createColourChoice(colour, checked, nameAttr) {
    var n = nameAttr || "daisy-create-own-border";
    return [
      '<label class="daisy-street-options__choice daisy-create-own-options__swatch-choice">',
      '<input type="radio" name="' + escapeHtml(n) + '" value="' + escapeHtml(colour.value) + '"' + (checked ? " checked" : "") + ">",
      '<span class="daisy-create-own-options__swatch" style="--daisy-swatch-color:' + escapeHtml(colour.colour) + '"></span>',
      '<span class="daisy-create-own-options__swatch-label">' + escapeHtml(colour.title) + "</span>",
      "</label>"
    ].join("");
  }

  function ensureScopedStyles() {
    if (qs(document, "[data-daisy-create-own-styles]")) return;
    var style = document.createElement("style");
    style.setAttribute("data-daisy-create-own-styles", "");
    style.textContent = [
      ".daisy-create-own-options{margin-top:0;display:block!important;visibility:visible!important;opacity:1!important;}",
      ".daisy-create-own-options .daisy-street-options__header{padding-bottom:14px;margin-bottom:14px;}",
      ".daisy-create-own-options .daisy-street-options__title{margin:0 0 4px;}",
      ".daisy-create-own-options .daisy-street-options__eyebrow{margin:0 0 5px;}",
      ".daisy-create-own-options .dm-direct-sign-editor{position:relative;width:calc(100% + 14px);max-width:none;margin:0 0 12px -7px;overflow:visible;}",
      ".daisy-create-own-options .dm-direct-sign-editor--offer{width:calc(100% + 8px);margin:0 0 12px -4px;}",
      ".daisy-create-own-options .dm-direct-sign-editor .dm-sign-preview__sign{display:block;width:100%;height:auto;}",
      ".daisy-create-own-options .dm-direct-sign-editor .dm-sign-preview__sign{pointer-events:none;}",
      "@keyframes dm-preview-caret-blink{0%,46%{opacity:1}47%,100%{opacity:0}}",
      ".daisy-create-own-options .dm-sign-preview__caret{display:none;animation:dm-preview-caret-blink 1s steps(1,end) infinite;pointer-events:none;}",
      ".daisy-create-own-options .dm-direct-sign-editor__fields{position:absolute;inset:0;z-index:2;pointer-events:none;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field{position:absolute;left:8%;width:84%;display:flex;align-items:center;justify-content:center;margin:0;pointer-events:auto;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field--one{top:20%;height:49%;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field--two{top:69%;height:20%;left:10%;width:80%;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field input{display:block;width:100%;height:100%;min-height:0;margin:0;padding:0 3px;border:0;border-radius:0;background:transparent;color:transparent!important;-webkit-text-fill-color:transparent!important;box-shadow:none;font-family:'DaisyStreetSignTimes','Times New Roman',serif!important;font-style:normal;font-weight:400!important;font-synthesis:none;text-align:center;text-transform:uppercase;line-height:1;letter-spacing:0;outline:0;caret-color:transparent;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field input::placeholder{color:transparent!important;-webkit-text-fill-color:transparent!important;opacity:0;}",
      ".daisy-create-own-options .dm-direct-sign-editor__field input:focus,.daisy-create-own-options .dm-direct-sign-editor__field input:focus-visible{background:transparent;border:0;outline:0;box-shadow:none;}",
      ".daisy-create-own-options .dm-direct-sign-editor__sr-only{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important;}",
      ".daisy-create-own-options__ready{display:flex;align-items:center;gap:9px;max-height:0;margin:-5px 0 0;padding:0 12px;overflow:hidden;border:0 solid transparent;border-radius:8px;background:#edf8ef;color:#205d2b;opacity:0;transform:translateY(-4px);transition:max-height .2s ease,margin .2s ease,padding .2s ease,opacity .16s ease,transform .2s ease;pointer-events:none;}",
      ".daisy-create-own-options__ready.is-visible{max-height:64px;margin:0 0 12px;padding:9px 12px;border-width:1px;border-color:#9bcba3;opacity:1;transform:translateY(0);}",
      ".daisy-create-own-options__ready-tick{display:grid;place-items:center;width:23px;height:23px;flex:0 0 23px;border-radius:999px;background:#2f8a42;color:#fff;font-size:14px;font-weight:900;line-height:1;}",
      ".daisy-create-own-options__ready-copy{display:flex;flex-direction:column;gap:1px;min-width:0;font-size:12px;line-height:1.2;}",
      ".daisy-create-own-options__ready-copy strong{color:#174d21;font-size:13px;font-weight:800;}",
      ".daisy-create-own-options__free-note{display:inline-flex;align-items:center;width:max-content;max-width:100%;margin-top:8px;padding:5px 9px;border-radius:999px;background:#f6f5f0;color:#3d3d35;font-size:12px;font-weight:700;}",
      ".daisy-create-own-options__swatch-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:7px;}",
      ".daisy-create-own-options__swatch-choice{display:flex!important;min-height:68px;padding:8px 4px;gap:6px;text-align:center;justify-content:center;align-items:center;flex-direction:column!important;min-width:0;}",
      ".daisy-create-own-options__swatch-choice input{position:absolute;opacity:0;pointer-events:none;}",
      ".daisy-create-own-options__swatch{width:28px;height:28px;border-radius:999px;background:var(--daisy-swatch-color);border:2px solid #fff;box-shadow:0 0 0 1px rgba(35,35,35,.22);display:block;margin:0 auto;flex:0 0 auto;}",
      ".daisy-create-own-options__swatch-label{display:block;width:auto;max-width:100%;font-size:11px;font-weight:700;line-height:1.05;color:#34342f;white-space:nowrap;}",
      ".daisy-create-own-options__swatch-choice.is-selected{border-color:#232323;background:#fafaf7;box-shadow:0 0 0 1px #232323 inset;}",
      ".daisy-create-own-options__swatch-choice.is-selected .daisy-create-own-options__swatch{box-shadow:0 0 0 2px #232323,0 2px 7px rgba(0,0,0,.18);}",
      ".daisy-create-own-options .daisy-street-options__offer.is-selected{border-color:#232323;background:#f4f3ed;box-shadow:0 0 0 1px #232323 inset;}",
      '.daisy-create-own-options .daisy-street-options__offer.is-selected .daisy-street-options__choice-title:after{content:"Selected";display:inline-flex;margin-left:7px;padding:2px 6px;border-radius:999px;background:#232323;color:#fff;font-size:10px;line-height:1;font-weight:800;vertical-align:middle;}',
      ".daisy-create-own-options .daisy-street-options__footer{margin-top:12px;padding:12px 14px;border:1px solid #d7d3c5;background:#f8f7f2;border-radius:8px;}",
      ".daisy-create-own-options .daisy-street-options__total{font-size:17px;color:#232323;}",
      ".daisy-create-own-options-ready .productView-ViewingProduct,.daisy-create-own-options-ready .productView-hotStock,.daisy-create-own-options-ready .product-customInformation[data-custom-information]{display:none!important;}",
      ".daisy-create-own-options-ready .price-countdown-widget,.daisy-create-own-options-ready #dm-gift-upsell,.daisy-create-own-options-ready .dm-gift-upsell,.daisy-create-own-options-ready #dm-cyg,.daisy-create-own-options-ready .dm-cyg{display:none!important;}",
      '.daisy-create-own-options-ready .halo-productView-right [class*="feefo"],.daisy-create-own-options-ready .halo-productView-right [id*="feefo"],.daisy-create-own-options-ready .halo-productView-right [data-feefo]{display:none!important;}',
      ".daisy-create-own-options-ready #dm-sticky-cart,.daisy-create-own-options-ready .dm-sticky-cart,.daisy-create-own-options-ready .sticky-add-to-cart,.daisy-create-own-options-ready .halo-sticky-add-to-cart,.daisy-create-own-options-ready [data-sticky-add-to-cart],.daisy-create-own-options-ready .productView-stickyCart{display:none!important;}",
      ".daisy-create-own-options-ready #shopify-section-halo-toolbar-mobile,.daisy-create-own-options-ready .halo-toolbar-mobile,.daisy-create-own-options-ready .halo-toolbar-bottom,.daisy-create-own-options-ready .halo-toolbar,.daisy-create-own-options-ready .toolbar-bottom,.daisy-create-own-options-ready .bottom-bar,.daisy-create-own-options-ready .mobile-toolbar{display:none!important;}",
      ".daisy-create-own-options-ready #halo-recently-viewed-wrap,.daisy-create-own-options-ready #halo-recently-viewed-popup,.daisy-create-own-options-ready .halo-recently-viewed,.daisy-create-own-options-ready .halo-recently-viewed-popup{display:none!important;}",
      ".daisy-create-own-options-ready .custom-cursor,.daisy-create-own-options-ready .custom-cursor__inner,.daisy-create-own-options-ready .arrow-bar{display:none!important;}",
      ".daisy-create-own-options-ready .dm-trust-badges{margin:12px 0 0;display:flex;flex-wrap:wrap;gap:8px;}",
      "@media(max-width:520px){.daisy-create-own-options{margin-bottom:10px}.daisy-create-own-options .dm-direct-sign-editor{width:calc(100% + 10px);margin-left:-5px}.daisy-create-own-options .dm-direct-sign-editor--offer{width:calc(100% + 4px);margin-left:-2px}.daisy-create-own-options__swatch-grid{gap:5px}.daisy-create-own-options__swatch-choice{min-height:66px;padding:7px 2px}.daisy-create-own-options__swatch{width:26px;height:26px}.daisy-create-own-options__swatch-label{font-size:9px}.daisy-create-own-options .daisy-street-options__footer{margin-top:10px;padding:10px 12px}}"
    ].join("");
    document.head.appendChild(style);
  }

  function createPanel() {
    var panel = document.createElement("div");
    panel.className = "daisy-street-options daisy-create-own-options";
    panel.setAttribute("data-daisy-create-own-options", "");
      panel.innerHTML = [
      signPreviewHTML(),
      '<div class="daisy-create-own-options__ready" data-daisy-create-ready role="status" aria-live="polite" aria-hidden="true">',
      '<span class="daisy-create-own-options__ready-tick" aria-hidden="true">&#10003;</span>',
      '<span class="daisy-create-own-options__ready-copy"><strong>Personalisation complete</strong><span>Ready to add to cart</span></span>',
      '</div>',

      // ── Header ──────────────────────────────────────────────────────────────
      '<div class="daisy-street-options__header">',
      '<h2 class="daisy-street-options__title">Family street sign</h2>',
      '<p class="daisy-street-options__eyebrow">Personalised to order</p>',
      '<p class="daisy-street-options__copy">Add your family wording, choose the finish, then pick your size and extras.</p>',
      '<span class="daisy-create-own-options__free-note">Free personalisation included</span>',
      "</div>",

      // ── Colour border ────────────────────────────────────────────────────────
      '<div class="daisy-street-options__group">',
      '<p class="daisy-street-options__group-title">Colour border</p>',
      '<div class="daisy-create-own-options__swatch-grid">',
      BORDER_COLOURS.map(function (c, i) { return createColourChoice(c, i === 4, "daisy-create-own-border"); }).join(""),
      "</div>",
      "</div>",

      // ── Size ─────────────────────────────────────────────────────────────────
      '<div class="daisy-street-options__group">',
      '<p class="daisy-street-options__group-title">Size</p>',
      '<div class="daisy-street-options__size-grid">',
      createChoice("radio", "daisy-create-own-size", "small",  true,  "Small",  "28 x 8.5cm", "Included",                   "daisy-street-options__choice--size"),
      createChoice("radio", "daisy-create-own-size", "medium", false, "Medium", "45 x 12cm", "+" + money(SP.medium / 100), "daisy-street-options__choice--size"),
      createChoice("radio", "daisy-create-own-size", "large",  false, "Large",  "57 x 12cm", "+" + money(SP.large / 100),  "daisy-street-options__choice--size"),
      "</div>",
      "</div>",

      // ── Incredible offer ─────────────────────────────────────────────────────
      '<div class="daisy-street-options__group">',
      '<p class="daisy-street-options__group-title">Incredible offer</p>',
      '<div class="daisy-street-options__grid">',
      createChoice("checkbox", "daisy-family-offer", "yes", false,
        "INCREDIBLE OFFER: Get a second sign for just " + money(SP.second / 100),
        "A matching sign — personalise it differently if you like",
        "+" + money(SP.second / 100),
        "daisy-street-options__offer"
      ),
      "</div>",
      // Second sign detail — expands here when offer is ticked
      '<div data-daisy-family-offer-panel style="display:none;margin-top:12px;padding:12px;border:1px solid #d7d3c5;border-radius:8px;background:#fafaf8;">',
      '<p class="daisy-street-options__group-title" style="margin:0 0 10px;font-size:13px;">Your second sign</p>',
      offerSignPreviewHTML(),
      '<p class="daisy-street-options__group-title" style="margin:10px 0 6px;font-size:12px;">Colour border</p>',
      '<div class="daisy-create-own-options__swatch-grid">',
      BORDER_COLOURS.map(function (c, i) { return createColourChoice(c, i === 4, "daisy-family-offer-border"); }).join(""),
      "</div>",
      '<p class="daisy-street-options__group-title" style="margin:10px 0 6px;font-size:12px;">Size</p>',
      '<div class="daisy-street-options__size-grid">',
      createChoice("radio", "daisy-family-offer-size", "small",  true,  "Small",  "28 x 8.5cm", "Included",                   "daisy-street-options__choice--size"),
      createChoice("radio", "daisy-family-offer-size", "medium", false, "Medium", "45 x 12cm", "+" + money(SP.medium / 100), "daisy-street-options__choice--size"),
      createChoice("radio", "daisy-family-offer-size", "large",  false, "Large",  "57 x 12cm", "+" + money(SP.large / 100),  "daisy-street-options__choice--size"),
      "</div>",
      "</div>",
      "</div>",

      // ── Add-ons ──────────────────────────────────────────────────────────────
      '<div class="daisy-street-options__group">',
      '<p class="daisy-street-options__group-title">Add-ons</p>',
      '<div class="daisy-street-options__grid">',
      '<label class="daisy-street-options__choice daisy-street-options__offer">',
      '<input type="checkbox" name="daisy-create-own-mounting" value="yes">',
      addonThumb.apply(null, THUMBS.mounting),
      '<span class="daisy-street-options__choice-main">',
      '<span class="daisy-street-options__choice-title">Mounting Strips <span class="daisy-street-options__recommended">Recommended</span></span>',
      '<span class="daisy-street-options__choice-note" data-daisy-family-mounting-note>Easy wall mounting add-on</span>',
      "</span>",
      '<span class="daisy-street-options__price" data-daisy-family-mounting-price>+' + money(SP.mounting / 100) + "</span>",
      "</label>",
      '<label class="daisy-street-options__choice daisy-street-options__offer"><input type="checkbox" name="daisy-easel-addon" value="yes">' + addonThumb.apply(null, THUMBS.easel) + '<span class="daisy-street-options__choice-main"><span class="daisy-street-options__choice-title">Wooden Display Easel</span><span class="daisy-street-options__choice-note">Ready to display straight from the box</span></span><span class="daisy-street-options__price">' + '+£' + ((SP.easel || 395) / 100).toFixed(2) + '</span></label>',
      '<label class="daisy-street-options__choice daisy-street-options__offer">',
      '<input type="checkbox" name="daisy-create-own-gift-wrap" value="yes">',
      addonThumb.apply(null, THUMBS.giftwrap),
      '<span class="daisy-street-options__choice-main">',
      '<span class="daisy-street-options__choice-title">Gift Wrap Kit</span>',
      '<span class="daisy-street-options__choice-note" data-daisy-family-giftwrap-note>Add gift-ready wrapping</span>',
      "</span>",
      '<span class="daisy-street-options__price" data-daisy-family-giftwrap-price>+' + money((SP.giftWrap || 495) / 100) + "</span>",
      "</label>",
      "</div>",
      "</div>",

      '<div class="daisy-street-options__error" data-daisy-create-error></div>',
      '<div class="daisy-street-options__footer">',
      "<span>Selected add-ons</span>",
      '<strong class="daisy-street-options__total" data-daisy-create-total>\xA30.00</strong>',
      "</div>",
      '<div data-daisy-create-cart-slot style="margin-top:12px;"></div>'
    ].join("");
    return panel;
  }

  function quantity(form) {
    var input = qs(form, 'input[name="quantity"]');
    var v = input ? parseInt(input.value, 10) : 1;
    return v > 0 ? v : 1;
  }

  function state(panel) {
    var size        = qs(panel, 'input[name="daisy-create-own-size"]:checked');
    var border      = qs(panel, 'input[name="daisy-create-own-border"]:checked');
    var mounting    = qs(panel, 'input[name="daisy-create-own-mounting"]');
    var giftWrap    = qs(panel, 'input[name="daisy-create-own-gift-wrap"]');
    var offer       = qs(panel, 'input[name="daisy-family-offer"]');
    var offerSize   = qs(panel, 'input[name="daisy-family-offer-size"]:checked');
    var offerBorder = qs(panel, 'input[name="daisy-family-offer-border"]:checked');
    return {
      size:         size        ? size.value        : "small",
      border:       border      ? border.value      : "black",
      sign:         "street sign",
      lineOne:      clean(qs(panel, "[data-daisy-create-line-one]")         && qs(panel, "[data-daisy-create-line-one]").value),
      lineTwo:      clean(qs(panel, "[data-daisy-create-line-two]")         && qs(panel, "[data-daisy-create-line-two]").value),
      easel:        !window.DaisyCleanProduct && !!(qs(panel, 'input[name="daisy-easel-addon"]') && qs(panel, 'input[name="daisy-easel-addon"]').checked),
      mounting:     !!(mounting  && mounting.checked),
      giftWrap:     !window.DaisyCleanProduct && !!(giftWrap  && giftWrap.checked),
      offer:        !window.DaisyCleanProduct && !!(offer     && offer.checked),
      offerSize:    offerSize    ? offerSize.value   : "small",
      offerBorder:  offerBorder  ? offerBorder.value : "black",
      offerLineOne: clean(qs(panel, "[data-daisy-family-offer-line-one]")  && qs(panel, "[data-daisy-family-offer-line-one]").value),
      offerLineTwo: clean(qs(panel, "[data-daisy-family-offer-line-two]")  && qs(panel, "[data-daisy-family-offer-line-two]").value)
    };
  }

  function updateSelected(panel) {
    qsa(panel, ".daisy-street-options__choice").forEach(function (choice) {
      var field = qs(choice, "input");
      choice.classList.toggle("is-selected", !!(field && field.checked));
    });
  }

  function updateReadyState(panel, cur) {
    var ready = qs(panel, "[data-daisy-create-ready]");
    if (!ready) return;
    var complete = !!(cur && cur.lineOne && cur.lineOne.length);
    ready.classList.toggle("is-visible", complete);
    ready.setAttribute("aria-hidden", complete ? "false" : "true");
  }

  function toggleOfferPanel(panel) {
    var cur = state(panel);
    var offerPanel = qs(panel, "[data-daisy-family-offer-panel]");
    if (offerPanel) offerPanel.style.display = cur.offer ? "" : "none";

    // Mounting: single → pair pack when second sign selected
    var mPrice = qs(panel, "[data-daisy-family-mounting-price]");
    var mNote  = qs(panel, "[data-daisy-family-mounting-note]");
    if (mPrice) mPrice.textContent = cur.offer ? "+" + money((SP.mountingPair || 399) / 100) : "+" + money((SP.mounting || 225) / 100);
    if (mNote)  mNote.textContent  = cur.offer ? "For both signs \xB7 one pair each" : "Easy wall mounting add-on";

    // Gift wrap: £4.95 → £9.90 when second sign selected
    var gPrice = qs(panel, "[data-daisy-family-giftwrap-price]");
    var gNote  = qs(panel, "[data-daisy-family-giftwrap-note]");
    if (gPrice) gPrice.textContent = "+" + money((SP.giftWrap || 495) * (cur.offer ? 2 : 1) / 100);
    if (gNote)  gNote.textContent  = cur.offer ? "Gift-ready wrapping for both signs" : "Add gift-ready wrapping";
  }

  function updateTotal(panel) {
    var cur = state(panel);
    var total = 0;
    if (cur.easel) total += (SP.easel || 395) / 100;

    if (cur.size === "medium") total += SP.medium / 100;
    if (cur.size === "large")  total += SP.large  / 100;

    if (cur.mounting) total += cur.offer ? (SP.mountingPair || 399) / 100 : (SP.mounting || 225) / 100;
    if (cur.giftWrap) total += (SP.giftWrap || 495) * (cur.offer ? 2 : 1) / 100;

    if (cur.offer) {
      total += SP.second / 100;
      if (cur.offerSize === "medium") total += SP.medium / 100;
      if (cur.offerSize === "large")  total += SP.large  / 100;
    }

    if (window.DaisyCleanProduct) {
      var selected = window.DaisyCleanProduct.variants.find(function (v) { return v.title.toLowerCase() === cur.size; });
      if (selected) total = (selected.price + (cur.mounting ? SP.mounting : 0)) / 100;
    }
    var totalNode = qs(panel, "[data-daisy-create-total]");
    if (totalNode) totalNode.textContent = money(total);
    updateReadyState(panel, cur);
    updateSelected(panel);
    toggleOfferPanel(panel);
    updatePreviews(panel);
  }

  function showError(panel, message) {
    var error = qs(panel, "[data-daisy-create-error]");
    if (error) { error.textContent = message; error.classList.add("is-visible"); error.scrollIntoView({ behavior: "smooth", block: "center" }); }
  }

  function clearError(panel) {
    var error = qs(panel, "[data-daisy-create-error]");
    if (error) { error.textContent = ""; error.classList.remove("is-visible"); }
  }

  function validate(panel) {
    var cur = state(panel);
    if (!cur.lineOne) return "Please add personalised text line one.";
    if (cur.offer && !cur.offerLineOne) return "Please add personalised text line one for your second sign.";
    return "";
  }

  function linkedProperties(bundleId) {
    return {
      "_Linked product": LINKED_PRODUCT,
      "_Bundle ID": bundleId
    };
  }

  function mergeProperties(base, extra) {
    var merged = {};
    Object.keys(base || {}).forEach(function (key) { merged[key] = base[key]; });
    Object.keys(extra || {}).forEach(function (key) { merged[key] = extra[key]; });
    return merged;
  }

  function signSizeLabel(size) {
    return size === "medium"
      ? "Medium 45 x 12cm (+" + money(SP.medium / 100) + ")"
      : size === "large"
        ? "Large 57 x 12cm (+" + money(SP.large / 100) + ")"
        : "Small 28 x 12cm";
  }

  function sizeUpgradeLine(size, quantityValue, bundleId, appliesTo) {
    if (size !== "medium" && size !== "large") return null;
    var properties = { "Upgrade": size === "medium" ? "Medium 45 x 12cm" : "Large 57 x 12cm" };
    if (appliesTo) properties["Applies to"] = appliesTo;
    return {
      id: size === "medium" ? ADDONS.mediumSign : ADDONS.largeSign,
      quantity: quantityValue,
      properties: mergeProperties(linkedProperties(bundleId), properties)
    };
  }

  function cartItems(form, panel, bundleId) {
    var cur = state(panel);
    var qty = quantity(form);

    var items = [{
      id: MAIN_VARIANT_ID,
      quantity: qty,
      properties: {
        "Line 1": cur.lineOne,
        "Line 2": cur.lineTwo || "",
        "Colour border": cur.border,
        "Size": signSizeLabel(cur.size),
        "_Custom option flow": "Daisy native family street sign options",
        "_Bundle ID": bundleId
      }
    }];

    var mainUpgrade = sizeUpgradeLine(cur.size, qty, bundleId);
    if (mainUpgrade) items.push(mainUpgrade);

    if (cur.mounting) {
      if (cur.offer) {
        items.push({ id: ADDONS.mountingPair, quantity: qty, properties: mergeProperties(linkedProperties(bundleId), { "Add-on": "Mounting Strips (pair pack)" }) });
      } else {
        items.push({ id: ADDONS.mountingStrips, quantity: qty, properties: mergeProperties(linkedProperties(bundleId), { "Add-on": "Mounting Strips" }) });
      }
    }

    if (cur.giftWrap) {
      items.push({ id: ADDONS.giftWrapKit, quantity: cur.offer ? 2 : 1, properties: mergeProperties(linkedProperties(bundleId), { "Add-on": "Gift Wrap Kit" }) });
    }

    if (cur.offer) {
      items.push({
        id: ADDONS.secondSign,
        quantity: qty,
        properties: mergeProperties(linkedProperties(bundleId), {
          "Offer": "Second sign",
          "Line 1": cur.offerLineOne,
          "Line 2": cur.offerLineTwo || "",
          "Colour border": cur.offerBorder,
          "Size": signSizeLabel(cur.offerSize)
        })
      });
      var secondUpgrade = sizeUpgradeLine(cur.offerSize, qty, bundleId, "Second sign");
      if (secondUpgrade) items.push(secondUpgrade);
    }

    if (cur.easel) items.push({ id: (window.DAISY_SS_IDS && DAISY_SS_IDS.easel) || 54200245387603, quantity: qty, properties: mergeProperties(linkedProperties(bundleId), { "Add-on": "Wooden Display Easel" }) });
    if (window.DAISY_NATIVE_STREET && window.DAISY_NATIVE_STREET.enabled) {
      if (!window.DaisyNativeStreetSizes) throw new Error('The sign options are still loading. Please refresh the page.');
      return window.DaisyNativeStreetSizes.transform(items, window.DAISY_NATIVE_STREET, { main: cur.size, second: cur.offerSize });
    }
    return items;
  }

  function resetLoading() {
    submitting = false;
    qsa(document, "[data-daisy-create-submit],.dm-sticky-btn").forEach(function (btn) {
      if (btn) { btn.textContent = btn.dataset.daisyOriginalText || btn.textContent.replace(/^Adding\.\.\.$/, "Add to cart"); btn.disabled = false; }
    });
  }

  function setLoading(on) {
    if (!on) { resetLoading(); return; }
    submitting = true;
    qsa(document, "[data-daisy-create-submit],.dm-sticky-btn").forEach(function (btn) {
      if (btn) { if (!btn.dataset.daisyOriginalText) btn.dataset.daisyOriginalText = btn.textContent; btn.textContent = "Adding..."; btn.disabled = true; }
    });
  }

  function addBundle(items) {
    if (window.DaisyNativeStreetSizes && window.DaisyNativeStreetSizes.active(window.DAISY_NATIVE_STREET)) return window.DaisyNativeStreetSizes.submit(items);
    var controller = typeof AbortController !== "undefined" ? new AbortController() : null;
    var tid = window.setTimeout(function () { if (controller) controller.abort(); }, CART_TIMEOUT_MS);
    return fetch("/cart/add.js", {
      method: "POST",
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      credentials: "same-origin",
      body: JSON.stringify({ items: items.map(function (item) {
        return { id: item.id, quantity: item.quantity, properties: item.properties };
      }) }),
      signal: controller ? controller.signal : undefined
    }).then(function (res) {
      window.clearTimeout(tid);
      if (res.ok) return res.json();
      return res.json().catch(function () { return {}; }).then(function (body) {
        throw new Error(body.description || body.message || "The selected products could not be added to basket.");
      });
    }).catch(function (err) {
      window.clearTimeout(tid);
      if (err && err.name === "AbortError") throw new Error("Adding to basket timed out. Please try again.");
      throw err;
    });
  }

  function submitBundle(form, panel) {
    if (submitting) return;
    clearError(panel);
    var v = validate(panel);
    if (v) { showError(panel, v); return; }
    setLoading(true);
    var bundleId = "family-street-sign-" + Date.now();
    Promise.resolve().then(function () { return addBundle(cartItems(form, panel, bundleId)); }).then(function () {
      window.location.href = (window.routes && window.routes.cart) || "/cart";
    }).catch(function (err) {
      console.error("[Daisy family street sign] cart error", err);
      setLoading(false);
      showError(panel, err.message || "Something went wrong adding to basket.");
    });
  }

  function stopNative(e) { if (e) { e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); } }

  function hideOldOptions() {
    qsa(document, '.gpo-container,.gpo-app,.gpo-options,.globo-product-options,.globo-options,.globo-formbuilder,[class*="globo-product"],[id*="globo-product"],[data-gpo],[data-globo]').forEach(function (node) {
      if (node.closest(".daisy-street-options")) return;
      node.setAttribute("aria-hidden", "true"); node.style.display = "none";
      qsa(node, "input,select,textarea,button").forEach(function (f) { f.disabled = true; });
    });
  }

  function nearestProductBlock(node) {
    return node ? (node.closest(".productView-moreItem") || node.closest(".productView-info-item") || node.closest(".productView-property") || node.closest(".productView-text") || node) : null;
  }

  function hideNode(node) {
    if (!node || node.closest(".daisy-street-options")) return;
    node.setAttribute("aria-hidden", "true");
    node.style.setProperty("display", "none", "important");
  }

  function moveTrustBadgesNearCart(form) {
    var badges = qs(document, ".dm-trust-badges");
    if (!badges || badges.dataset.daisyCreateMoved) return;
    var proof = window.DAISY_PROOF || {};
    badges.className = "dm-product-proof dm-product-proof--quote";
    badges.setAttribute("aria-label", "Customer review");
    badges.innerHTML = [
      '<div class="dm-product-proof__stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</div>',
      '<blockquote class="dm-product-proof__quote">' + (proof.quote || "Rated 5 stars by verified customers") + "</blockquote>",
      '<p class="dm-product-proof__meta">' + (proof.meta || "Verified customer") + "</p>"
    ].join("");
    var price = qs(document, ".productView-price");
    if (price && price.parentNode) {
      price.parentNode.insertBefore(badges, price.nextSibling);
    } else {
      var atc = qs(document, "#product-add-to-cart") || qs(form, 'button[name="add"]');
      var target = atc && (atc.closest(".productView-group") || atc.closest(".product-form__buttons") || atc.parentElement);
      if (target && target.parentNode) target.parentNode.insertBefore(badges, target.nextSibling);
    }
    badges.dataset.daisyCreateMoved = "true";
    addProofBarNearCart(form);
  }

  function addProofBarNearCart(form) {
    if (qs(document, ".dm-product-quote--proof")) return;
    var proof = window.DAISY_PROOF || {};
    var atc = qs(document, "#product-add-to-cart") || qs(form, 'button[name="add"]');
    var target = atc && (atc.closest(".productView-group") || atc.closest(".product-form__buttons") || atc.parentElement);
    if (!target || !target.parentNode) return;
    var bar = document.createElement("aside");
    bar.className = "dm-product-quote dm-product-quote--proof";
    bar.setAttribute("aria-label", "Customer rating");
    bar.innerHTML = '<div class="dm-product-quote__stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</div><p class="dm-product-quote__text">' + (proof.line || "Rated 5 stars by verified customers") + "</p>";
    target.parentNode.insertBefore(bar, target);
  }

  function hideConflictingPromoBoxes(form) {
    var scope = getProductColumn(form) || form.parentElement || document;
    qsa(scope, ".price-countdown-widget,#dm-gift-upsell,.dm-gift-upsell,#dm-cyg,.dm-cyg").forEach(function (n) { if (!n.closest(".dm-trust-badges") && !n.closest(".dm-product-proof") && !n.closest(".dm-product-quote")) hideNode(nearestProductBlock(n)); });
    qsa(scope, '[class*="feefo"],[id*="feefo"],[data-feefo]').forEach(function (n) { if (!n.closest(".dm-trust-badges") && !n.closest(".dm-product-proof") && !n.closest(".daisy-street-options")) hideNode(n.closest(".productView-moreItem") || n); });
    qsa(document, "#dm-sticky-cart,.dm-sticky-cart,.sticky-add-to-cart,.halo-sticky-add-to-cart,[data-sticky-add-to-cart],.productView-stickyCart,.custom-cursor,.custom-cursor__inner,.arrow-bar").forEach(hideNode);
    qsa(document, "#shopify-section-halo-toolbar-mobile,.halo-toolbar-mobile,.halo-toolbar-bottom,.halo-toolbar,.toolbar-bottom,.bottom-bar,.mobile-toolbar").forEach(hideNode);
    qsa(document, "#halo-recently-viewed-wrap,#halo-recently-viewed-popup,.halo-recently-viewed,.halo-recently-viewed-popup").forEach(hideNode);
    qsa(scope, ".productView-ViewingProduct,.productView-hotStock,.product-customInformation[data-custom-information]").forEach(function (n) { hideNode(nearestProductBlock(n)); });
    qsa(scope, ".productView-moreItem,.productView-property,.productView-info-item,.productView-text,.productView-securityImage,.productView-meta,.price-countdown-widget,.dm-gift-upsell,.dm-cyg").forEach(function (node) {
      if (!node || node.querySelector('form[data-type="add-to-cart-form"]') || node.closest(".daisy-street-options") || node.closest(".dm-trust-badges") || node.closest(".dm-product-proof") || node.closest(".dm-product-quote")) return;
      var text = clean(node.textContent).toLowerCase();
      if (!text) return;
      var hide = text.indexOf("5/5 feefo") !== -1 || text.indexOf("verified reviews") !== -1 || text.indexOf("gold trusted service") !== -1 || text.indexOf("customers are viewing this product") !== -1 || text.indexOf("customer is viewing this product") !== -1 || text.indexOf("get your own personalized street sign") !== -1 || text.indexOf("get your own personalised street sign") !== -1 || text.indexOf("add a gift card") !== -1 || text.indexOf("add a wedding congratulations card") !== -1 || text.indexOf("printed message") !== -1 || text.indexOf("gift card imprinted") !== -1 || text.indexOf("imprinted message") !== -1 || (text.indexOf("save ") !== -1 && text.indexOf("price increases") !== -1) || text.indexOf("sale price ends") !== -1 || text.indexOf("don't miss out") !== -1 || text === "sale" || (text.indexOf("sale") === 0 && text.length < 30) || text.indexOf("free personalisation") !== -1 || text.indexOf("free personalization") !== -1;
      if (hide) hideNode(nearestProductBlock(node));
    });
  }

  function placePanel(form, panel) {
    var f = form || getForm();
    if (!f) return;
    var anchor = qs(f, ".productView-buttons") || qs(f, ".productView-group") || null;
    var parent = f;
    if (panel.parentElement !== parent) {
      parent.insertBefore(panel, anchor || null);
    } else if (anchor && !(panel.compareDocumentPosition(anchor) & Node.DOCUMENT_POSITION_FOLLOWING)) {
      parent.insertBefore(panel, anchor);
    }
    panel.style.removeProperty("display");
    panel.style.removeProperty("visibility");
    panel.style.removeProperty("opacity");
  }

  function moveCartControlsAfterPanel(form, panel) {
    var slot = qs(panel, "[data-daisy-create-cart-slot]");
    var btn  = qs(form, 'button[name="add"],#product-add-to-cart');
    if (slot && btn) {
      btn.removeAttribute("id"); btn.type = "submit"; btn.name = "add";
      btn.setAttribute("data-daisy-create-submit", ""); btn.textContent = "Add to cart";
      if (btn.parentElement !== slot) slot.appendChild(btn);
    }
  }

  function bind(form, panel) {
    if (document.body.dataset.daisyCreateOwnSubmitBound) return;
    document.body.dataset.daisyCreateOwnSubmitBound = "true";
    document.addEventListener("click", function (e) {
      var t = e.target.closest && e.target.closest("[data-daisy-create-submit],.dm-sticky-btn");
      if (t) { stopNative(e); submitBundle(getForm() || form, qs(document, "[data-daisy-create-own-options]") || panel); }
    }, true);
    document.addEventListener("submit", function (e) {
      if (e.target === form) { stopNative(e); submitBundle(form, panel); }
    }, true);
    panel.addEventListener("input",  function () { updateTotal(panel); });
    panel.addEventListener("change", function () { updateTotal(panel); });
    panel.addEventListener("focusin", function () { window.requestAnimationFrame(function () { updatePreviewCaret(panel); }); });
    panel.addEventListener("focusout", function () { window.requestAnimationFrame(function () { updatePreviewCaret(panel); }); });
    panel.addEventListener("keyup", function () { updatePreviewCaret(panel); });
    panel.addEventListener("click", function () { window.requestAnimationFrame(function () { updatePreviewCaret(panel); }); });
    panel.addEventListener("select", function () { updatePreviewCaret(panel); });
    window.addEventListener("resize", function () { updateDirectEditors(panel); });
    window.addEventListener("pageshow", resetLoading);
    document.addEventListener("visibilitychange", function () { if (document.visibilityState === "visible") resetLoading(); });
  }

  function refresh(form, panel) {
    if (window.DaisyNativeStreetSizes) {
      window.DaisyNativeStreetSizes.initialiseSelection(panel, window.DAISY_NATIVE_STREET);
      window.DaisyNativeStreetSizes.hideNativeOptions(form, panel, window.DAISY_NATIVE_STREET);
    }
    hideOldOptions();
    placePanel(form, panel);
    moveCartControlsAfterPanel(form, panel);
    moveTrustBadgesNearCart(form);
    hideConflictingPromoBoxes(form);
    updateTotal(panel);
  }

  function watchLateBlocks(form, panel) {
    if (document.body.dataset.daisyCreateOwnObserverBound) return;
    document.body.dataset.daisyCreateOwnObserverBound = "true";
    var timer = null;
    new MutationObserver(function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(function () { refresh(getForm() || form, panel); }, 80);
    }).observe(document.body, { childList: true, subtree: true });
  }

  function init() {
    if (!isTargetProduct()) return;
    ensureScopedStyles();
    document.body.classList.add("daisy-street-sign-options-ready", "daisy-create-own-options-ready", "daisy-family-sign-ready");
    var form = getForm();
    if (!form) return;
    var panel = qs(document, "[data-daisy-create-own-options]") || createPanel();
    refresh(form, panel);
    bind(form, panel);
    watchLateBlocks(form, panel);
    resetLoading();
    if (document.fonts && document.fonts.load) {
      document.fonts.load('400 100px "' + PREVIEW_FONT + '"').then(function () { updatePreviews(panel); });
    }
    [300, 900, 1800, 3200].forEach(function (delay) {
      window.setTimeout(function () { refresh(getForm() || form, panel); }, delay);
    });
  }

  function initWhenReady(attempt) {
    if (!isTargetProduct()) return;
    init();
    if (!qs(document, "[data-daisy-create-own-options]") && attempt < 80) {
      window.setTimeout(function () { initWhenReady(attempt + 1); }, 150);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { initWhenReady(0); });
  } else {
    initWhenReady(0);
  }
})();


