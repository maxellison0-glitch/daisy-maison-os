(function () {
  'use strict';
  var config = window.DaisyCleanProduct;
  if (!config) return;
  var sizeSelector = 'input[name="daisy_sign_size"],input[name="daisy-create-own-size"],input[name="daisy-family-size"]';
  function currentVariant() {
    var field = document.querySelector(sizeSelector.split(',').map(function(s){return s + ':checked';}).join(','));
    var size = field && field.value === 'standard' ? 'small' : field && field.value;
    return config.variants.find(function(v){return v.title.toLowerCase() === size;}) || config.variants[0];
  }
  function update() {
    var variant = currentVariant();
    document.querySelectorAll(sizeSelector).forEach(function(input) {
      var title = input.value === 'standard' ? 'small' : input.value;
      var option = config.variants.find(function(v){return v.title.toLowerCase() === title;});
      var label = input.closest('label');
      var price = label && label.querySelector('.daisy-street-options__price');
      if (price && option && price.textContent !== option.formatted) price.textContent = option.formatted;
    });
    document.querySelectorAll('.productView-price').forEach(function(node) {
      var signature = variant.id + ':' + variant.price + ':' + variant.compare;
      if (node.dataset.cleanPrice === signature && node.querySelector('.dm-clean-price')) return;
      node.dataset.cleanPrice = signature;
      var wrap = document.createElement('div');
      wrap.className = 'dm-clean-price';
      var current = document.createElement('span');
      current.textContent = variant.formatted;
      wrap.appendChild(current);
      if (variant.compare > variant.price) {
        var was = document.createElement('s');
        was.textContent = variant.was;
        wrap.appendChild(was);
      }
      node.replaceChildren(wrap);
    });
    document.querySelectorAll('.productView .sale-badge,.productView .badge--sale').forEach(function(badge){badge.hidden = variant.compare <= variant.price;});
    var footer = document.querySelector('[data-daisy-create-total]');
    if (footer && footer.previousElementSibling && footer.previousElementSibling.textContent !== config.totalLabel) footer.previousElementSibling.textContent = config.totalLabel;
    var button = document.querySelector('#product-add-to-cart, [data-daisy-create-submit], .product-form__submit');
    if (button && !document.querySelector('.dm-clean-basket-note')) {
      var note = document.createElement('p');
      note.className = 'dm-clean-basket-note';
      note.textContent = config.basketNote;
      button.parentElement.insertAdjacentElement('afterend', note);
    }
  }
  var pending = false;
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(function(){pending=false;update();});
  }
  document.addEventListener('change', schedule);
  document.addEventListener('input', schedule);
  function init() {
    update();
    var area = document.querySelector('.productView');
    if (area) new MutationObserver(schedule).observe(area, {childList:true,subtree:true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',init);
  else init();
})();

